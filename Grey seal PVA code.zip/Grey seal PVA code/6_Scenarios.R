#Daire Carroll University of Gothenburg 2022
#Grey seal PVA script 6, testing various hunting and environmental change scenarios

setwd("C:/Users/daire/Desktop/Projects/Grey Seal PVA/HG_PVA_Code/Data")
my.data = read.csv("Areial_Counts.csv", sep = ",", header = TRUE, fileEncoding = 'UTF-8-BOM')
ice.data = read.csv("ice.csv", sep = ",", header = TRUE, fileEncoding = 'UTF-8-BOM')

setwd("C:/Users/daire/Desktop")

E_Range = c(0) #increased entanglement ,0.01,0.02,0.03

fer = c(0,0.33519) #range of reduced fertility

H_sk_range = c("H_sk_1 = H_sk",
               #"H_sk_1 = rep(1/A,A)",
               "H_sk_1 = c(0,0,0,0,rep(1/(A-4), (A-4)))")


vals = c("K = K1", 
         "F = F1",
         "S = S1",
         "P0 = structure(F1,S1,P01)",
         "fer =c(0, 0.33519)",
         
         "K = K2", 
         "F = F2",
         "S = S2",
         "P0 = structure(F2,S2,P02)",
         "fer = c(0,(1/3))"
         
) #carying capacity scenarios


grp = c("eval(parse(text=vals[1:5])) ",
        "eval(parse(text=vals[6:10])) ")

#estimating mean ice coverage and number of good and bad years

mice = mean(ice.data$Extent) 
fb = length(which(ice.data$Extent<mice))/length(ice.data$Extent)#frequency of bad ice years to date

x = c(1,50,100)
yb = c(fb,((1-fb)/2 + fb),1)  
lmb = lm(yb~x)
P_ice = rbind(c(fb,0),lmb$coefficients) #two scenarios, first buisness as usual, constant ice coverage, next reduction of ice until there is a frequncy of 1 for bad ice years

S_G = c(0.779,S_1_Hunt[2:length(S_1_Hunt)]) #survival in a good year (high pup survival)
S_B = c(0.579,S_1_Hunt[2:length(S_1_Hunt)]) #survival in a good year (low pup survival)

P0 = structure(F1,S_1_Hunt,P01)

#####################Good year bad year simulations begin##################

H_Range_Q = c(0,400,800,1200,1600,2000,2400,2800,3200,3600,4000) #seals hunted, quota
H_Range_Q = H_Range_Q*0.43 #females hunted, quota

rep = 100 #1000

GYBY_Q = rep(NA,106)

eval(parse(text=grp[1]))

for(i in c(1:length(H_Range_Q))){
  
  H = H_Range_Q[i]
  
  for(j in c(1:length(fer))){
    
    for(m in c(1:nrow(P_ice))){
      
      for(k in c(1:length(H_sk_range))){
        
        lm_y = P_ice[m,]
        
        eval(parse(text=H_sk_range[k]))
        
        F_R = F - F*fer[j]
        
        Settings = c(H,fer[j],k,m,K)
        
        for(l in c(1:rep)){
          
          P = structure(F1,S_1_Hunt,P01)
          P_rep = c(sum(P))
          
          for(n in 1:100){
            
            Yr_P = as.numeric(n*lm_y[2] + lm_y[1])
            
            P = PopMod_gyby(t = 1, 
                            A = A, 
                            K_G = K, K_B = K_B, K_Yr_P = 0, 
                            P = P, 
                            B = F_R, 
                            S_G = S_G, S_B = S_B, Yr_P = Yr_P,
                            R = R,
                            H = H, 
                            H_sk = H_sk_1,
                            proportion = FALSE, 
                            E = 0, 
                            E_sk = E_sk, 
                            stru = TRUE)[,2]
            
            P_rep = c(P_rep,sum(P))
            
          }
          
          GYBY_Q = cbind(GYBY_Q,c(Settings,P_rep))
          
          #plot(c(rev(Estimate)/2,P_rep)~c(rev(Year),2021:(2021 + 100)),ylim = c(0,50000), main = Settings)
          
          print(paste(c(Settings,P_rep[length(P)])))
          
        }
        
      }
      
    }
    
  }
  
}

eval(parse(text=grp[2]))

for(i in c(1:length(H_Range_Q))){
  
  H = H_Range_Q[i]
  
  for(j in c(1:length(fer))){
    
    for(m in c(1:nrow(P_ice))){
      
      for(k in c(1:length(H_sk_range))){
        
        lm_y = P_ice[m,]
        
        eval(parse(text=H_sk_range[k]))
        
        F_R = F - F*fer[j]
        
        Settings = c(H,fer[j],k,m,K)
        
        for(l in c(1:rep)){
          
          P = structure(F1,S_1_Hunt,P01)
          P_rep = c(sum(P))
          
          for(n in 1:100){
            
            Yr_P = as.numeric(n*lm_y[2] + lm_y[1])
            
            P = PopMod_gyby(t = 1, 
                            A = A, 
                            K_G = K, K_B = K_B, K_Yr_P = 0, 
                            P = P, 
                            B = F_R, 
                            S_G = S_G, S_B = S_B, Yr_P = Yr_P,
                            R = R,
                            H = H, 
                            H_sk = H_sk_1,
                            proportion = FALSE, 
                            E = 0, 
                            E_sk = E_sk, 
                            stru = TRUE)[,2]
            
            P_rep = c(P_rep,sum(P))
            
          }
          
          GYBY_Q = cbind(GYBY_Q,c(Settings,P_rep))
          
          #plot(c(rev(Estimate)/2,P_rep)~c(rev(Year),2021:(2021 + 100)),ylim = c(0,50000), main = Settings)
          
          print(paste(c(Settings,P_rep[length(P)])))
          
        }
        
      }
      
    }
    
  }
  
}#10% chance of 10000 K_B, hunting = fixed quota

setwd("C:/Users/daire/Desktop")
write.csv(GYBY_Q, "GYBY.csv")

H_Range_Q = c(0,400,800,1200,1600,2000,2400,2800,3200,3600,4000) #seals hunted, quota
H_Range_Q = H_Range_Q*0.5 #females hunted, quota

GYBY_Q = rep(NA,106)

eval(parse(text=grp[1]))

for(i in c(1:length(H_Range_Q))){
  
  H = H_Range_Q[i]
  
  for(j in c(1:length(fer))){
    
    for(m in c(1:nrow(P_ice))){
      
      for(k in c(1:length(H_sk_range))){
        
        lm_y = P_ice[m,]
        
        eval(parse(text=H_sk_range[k]))
        
        F_R = F - F*fer[j]
        
        Settings = c(H,fer[j],k,m,K)
        
        for(l in c(1:rep)){
          
          P = structure(F1,S_1_Hunt,P01)
          P_rep = c(sum(P))
          
          for(n in 1:100){
            
            Yr_P = as.numeric(n*lm_y[2] + lm_y[1])
            
            P = PopMod_gyby(t = 1, 
                                  A = A, 
                                  K_G = K, K_B = K_B, K_Yr_P = 0, 
                                  P = P, 
                                  B = F_R, 
                                  S_G = S_G, S_B = S_B, Yr_P = Yr_P,
                                  R = R,
                                  H = H, 
                                  H_sk = H_sk_1,
                                  proportion = FALSE, 
                                  E = 0, 
                                  E_sk = E_sk, 
                                  stru = TRUE)[,2]
            
            P_rep = c(P_rep,sum(P))
            
          }
          
          GYBY_Q = cbind(GYBY_Q,c(Settings,P_rep))
          
          #plot(c(rev(Estimate)/2,P_rep)~c(rev(Year),2021:(2021 + 100)),ylim = c(0,50000), main = Settings)
          
          print(paste(c(Settings,P_rep[length(P)])))
          
        }
        
      }
      
    }
    
  }
  
}#10% chance of 10000 K_B, hunting = fixed quota

eval(parse(text=grp[2]))

for(i in c(1:length(H_Range_Q))){
  
  H = H_Range_Q[i]
  
  for(j in c(1:length(fer))){
    
    for(m in c(1:nrow(P_ice))){
      
      for(k in c(1:length(H_sk_range))){
        
        lm_y = P_ice[m,]
        
        eval(parse(text=H_sk_range[k]))
        
        F_R = F - F*fer[j]
        
        Settings = c(H,fer[j],k,m,K)
        
        for(l in c(1:rep)){
          
          P = structure(F1,S_1_Hunt,P01)
          P_rep = c(sum(P))
          
          for(n in 1:100){
            
            Yr_P = as.numeric(n*lm_y[2] + lm_y[1])
            
            P = PopMod_gyby(t = 1, 
                            A = A, 
                            K_G = K, K_B = K_B, K_Yr_P = 0, 
                            P = P, 
                            B = F_R, 
                            S_G = S_G, S_B = S_B, Yr_P = Yr_P,
                            R = R,
                            H = H, 
                            H_sk = H_sk_1,
                            proportion = FALSE, 
                            E = 0, 
                            E_sk = E_sk, 
                            stru = TRUE)[,2]
            
            P_rep = c(P_rep,sum(P))
            
          }
          
          GYBY_Q = cbind(GYBY_Q,c(Settings,P_rep))
          
          #plot(c(rev(Estimate)/2,P_rep)~c(rev(Year),2021:(2021 + 100)),ylim = c(0,50000), main = Settings)
          
          print(paste(c(Settings,P_rep[length(P)])))
          
        }
        
      }
      
    }
    
  }
  
}#10% chance of 10000 K_B, hunting = fixed quota

setwd("C:/Users/daire/Desktop")
write.csv(GYBY_Q, "GYBY_0.5.csv")

#####################Good year bad year simulations end##################

#####################Stochastic (R) simulations begin#######################

H_Range_Q = c(0,400,800,1200,1600,2000,2400,2800,3200,3600,4000) #seals hunted, quota
H_Range_Q = H_Range_Q*0.43 #females hunted, quota

Fer_Q = rep(NA,106)

for(i in c(1:length(H_Range_Q))){
  
  H = H_Range_Q[i]
  
  for(j in c(1:length(E_Range))){
    
    E = E_Range[j]
    
    for(m in c(1:length(grp))){
      
      eval(parse(text=grp[m])) 
      
      for(k in c(1:length(H_sk_range))){
        
        eval(parse(text=H_sk_range[k]))
        
        for(n in 1:length(fer)){
          
          F_R = F - F*fer[n]
          
          Settings = c(H,E,k,K,fer[n]) #k = 1 is skew, k = 2 is no skew
          
          for(l in c(1:rep)){
            
            P = PopMod(t = 100, 
                                  A = A, 
                                  K = K, 
                                  P = P0, 
                                  B = F_R, 
                                  S = S, 
                                  R = R, 
                                  H = H, 
                                  H_sk = H_sk_1,
                                  proportion = FALSE, 
                                  E = E, 
                                  E_sk = E_sk, 
                                  stru = FALSE)
            
            Fer_Q = cbind(Fer_Q,c(Settings,P))
            
            #plot(c(rev(Estimate)/2,P)~c(rev(Year),2021:(2021 + 100)), main = Settings)
            
            print(paste(c(Settings,P[length(P)])))
            
          }
          
        }
        
      }
      
    }
    
  }
  
}

write.csv(Fer_Q, "Multiistress.csv") #hunting = fixed quota, no GYBY dynamics

H_Range_Q = c(0,400,800,1200,1600,2000,2400,2800,3200,3600,4000) #seals hunted, quota
H_Range_Q = H_Range_Q*0.5 #females hunted, quota

Fer_Q = rep(NA,106)

for(i in c(1:length(H_Range_Q))){
  
  H = H_Range_Q[i]
  
  for(j in c(1:length(E_Range))){
    
    E = E_Range[j]
    
    for(m in c(1:length(grp))){
      
      eval(parse(text=grp[m])) 
      
      for(k in c(1:length(H_sk_range))){
        
        eval(parse(text=H_sk_range[k]))
        
        for(n in 1:length(fer)){
          
          F_R = F - F*fer[n]
          
          Settings = c(H,E,k,K,fer[n]) #k = 1 is skew, k = 2 is no skew
          
          for(l in c(1:rep)){
            
            P = PopMod(t = 100, 
                       A = A, 
                       K = K, 
                       P = P0, 
                       B = F_R, 
                       S = S, 
                       R = R, 
                       H = H, 
                       H_sk = H_sk_1,
                       proportion = FALSE, 
                       E = E, 
                       E_sk = E_sk, 
                       stru = FALSE)
            
            Fer_Q = cbind(Fer_Q,c(Settings,P))
            
            #plot(c(rev(Estimate)/2,P)~c(rev(Year),2021:(2021 + 100)), main = Settings)
            
            print(paste(c(Settings,P[length(P)])))
            
          }
          
        }
        
      }
      
    }
    
  }
  
}

write.csv(Fer_Q, "Multiistress_0.5.csv") #hunting = fixed quota, no GYBY dynamics

#####################Stochastic (R) simulations end#######################


