#Daire Carroll University of Gothenburg 2022
#Grey seal PVA script, estimated parameters for ppualiton growth in Baltic Grey Seals based on fitting

t = 100 #number of cycles representing 100 years

A = 47 #maximum age

logistic = function(y0,K,mu,x){
  (K * y0)/(y0 + (K - y0) * exp(-mu * x))
}

F26plus = 0.4166667
F = c(0,0,logistic(0.0004946038,0.8594168,1.572681,c(3:26)),rep((F26plus),(A)-26))#Each age class is assigned fertility of next cycle

K1 = 100000* 0.59
K2 = 88000* 0.59#carrying capacities

P01 = 55997.36 * 0.59
P02 = 55736.80 * 0.59#starting populations in 2020

P2009_1 = 31163.51 * 0.59
P2009_2 = 30968.65 * 0.59 #starting populations in 2009

F1 = F*1.041543
F2 = F*1.053192#estimated intrinsic fertilities

S1 = c(0.662       ,rep(0.932     , 3), rep(0.95     , (A-4)))
S2 = c(0.735       ,rep(0.932     , 3), rep(0.95     , (A-4))) #estimated survivals (disturbed population)

H_sk = c(0.21329365, 0.07440476, 0.06448413, 0.05555556, 0.07142857) #hunting skew 

E_sk = c(0.53741497, 0.08163265, 0.11224490, 0.11904762, 0.04081633) #entanglement skew

R = 0.053 #random variation term

Sex_Ratio = 0.59 #Females as proportion of population
Hunt_Ratio = 0.43 #Females in the hunt

S_1_Hunt = c(0.709     , rep(0.952    , 3), rep(0.962   , (A-4)))
S_2_Hunt = c(0.784     , rep(0.953     , 3), rep(0.962    , (A-4)))#estimated survivals (undisturbed population)

