#Daire Carroll University of Gothenburg 2022
#Grey seal PVA script, functions for predictive modelling

#t = number of cycles
#A
#K = carrying capacity 
#K_G = upper carrying capacity ('good year capacity')
#K_B = lower carrying capacity ('bad year capacity')
#K_Yr_P = probability of a bad year per cycle
#P = initial population as an age structured vector
#B = age specific birthrates as a vector
#S = age specific survival as a vector
#S_G = age specific survival as a vector (good year)
#S_B  = age specific survival as a vector (bad year)
#Yr_P = probability of a bad survival year per cycle
#R = random variation terms, maximum proportion added/subtracted from the population each cycle 
#H = size of hunt, either proportion or set quota
#H_sk = hunt skew, a vector expressing how the hunt should be applied to the population
#proportion = TRUE/FALSE if hunt should be applied as a proportion of the population (TRUE) or as a set quota (FALSE) 
#E = increase in entanglement, a proportion of the populaiton
#E_sk = entanglment skew, a vector expressing how the entanglment should be applied to the population
#stru = TRUE/FALSE if an age structured population should be returned for each cycle (TRUE) or a vector of the sums of populaiotn size for each cycle (FALSE) 

structure = function(B,S,N){
  B = B*S/2
  L = matrix(B,ncol = A)
  for(i in 1:(A-1)){
    x = numeric(A)
    x[i] = S[i]
    L = rbind(L, x)
  }
  ev = eigen(L)
  ev = as.numeric(ev$vectors[,1])
  P = c()
  for(i in 1:A){
    P[i] = ev[i]/sum(ev)*N
  } 
  return(P)
} #find dominant left eigen vector for given demographic scenario, with birthrates B (vector), survival S (vector) and popualiton size

eig_val = function(B,S){
  A = length(B)
  B = B*S/2
  L = matrix(B,ncol = A)
  for(i in 1:(A-1)){
    x = numeric(A)
    x[i] = S[i]
    L = rbind(L, x)
  }
  ev = eigen(L)
  return(as.numeric(ev$value[1]))
} #find dominant left eigen value for given demographic scenario

PopMod = function(t, A, K, P, B, S, R, H, H_sk, proportion, E, E_sk, stru){
  
  ###housekeeping and troubleshooting begin###
  
  if(t==0){		
    
    if(stru == TRUE){
      
      return(P)
      
    }else{
      
      return(sum(P))
      
    }
    
  } 
  
  null_args = list(H_sk,E_sk)
  null_args_names = c("H_sk","E_sk")
  for(i in 1:length(null_args)){
    if(is.null(null_args[[i]])){
      assign(paste0(null_args_names[i]), 0)
    }
  }
  
  if(length(P)!=A || (length(S))!=A || length(B)!=A){
    stop('Lengths of P, S, & B must = A')
  }
  
  ###housekeeping and troubleshooting end###
  
  ###function for Leslie matrix assembly begin###
  
  const_leslie = function(B,S){
    
    B = B*S/2
    
    L = matrix(B,ncol = A) 
    
    for(i in 1:(A-1)){
      x = numeric(A)
      x[i] = S[i]
      L = rbind(L, x)
    }	
    
    return(L)
    
  }
  
  ###function for Leslie matrix assembly end###
  
  P_out = matrix(0, nrow = length(P),ncol = t+1)
  P_out[,1] = P
  
  ###carrying capacity begin### 
  
  Keffect = function(K,ev1,TP){ 
    
    if(is.null(K)){
      return(1)
    }else{
      return(((K+(ev1-1)*TP)/K)^-1)
    }  
  } #calculate the effect of carrying capactity at t based on population size at t-1, currently for best L1 matrix dominent eigen value
  
  ###carrying capacity end###
  
  ###hunting and entanglement function start###
  
  if(proportion == TRUE){
    apply_H = function(PI,H,H_sk){
      
      if(length(H_sk)<A){
        H_sk = c(H_sk,(1-sum(H_sk))*(structure(B,S,1)[(length(H_sk)+1):A]/sum((structure(B,S,1)[(length(H_sk)+1):A]))))
      }
      
      basic_H = function(PI,H){
        
        PI = PI-PI*H
        return(PI)
        
      } #in cases where there is no skew hunting is applied evenly across age classes
      
      even_spread = function(reduction,neg_v,pos_v){
        
        while(length(neg_v)>0){
          
          deficit = c()
          
          for(i in 1:length(neg_v)){
            deficit[i] = reduction[neg_v[i]]
          }
          
          deficit = sum(deficit)
          
          for(i in 1:length(neg_v)){
            
            reduction[neg_v[i]] = 0
            
          }
          
          reduction_L = sum(reduction)
          
          for(i in 1:length(pos_v)){
            
            reduction[pos_v[i]] = reduction[pos_v[i]] + deficit*(reduction[pos_v[i]]/reduction_L) 
            
            neg_v = which(reduction<0)
            pos_v = which(reduction>0)
            
          }
          
        }
        
        return(reduction)
        
      } #when uneven hunting leads to depletion of an age class, deficit will be shared out based on proportion of the population 
      
      if(sum(H_sk) == 0){ 
        
        PI = basic_H(PI,H)
        
        return(PI) #with no hunting skew, basic hunting is applied across classes
        
      }else{
        
        reduction = PI-H_sk*H*sum(PI)
        
        neg_v = which(reduction<0)
        pos_v = which(reduction>0)
        
        PI = even_spread(reduction,neg_v,pos_v)
        
        return(PI) #in cases where hunting is applied as a vector, when an age class is depleted, the quota is met with individuals from other classes
        
      }
      
    }
    
  }else if(proportion == FALSE){
    apply_H = function(PI,H,H_sk){
      
      if(length(H_sk)<A){
        H_sk = c(H_sk,(1-sum(H_sk))*(structure(B,S,1)[(length(H_sk)+1):A]/sum((structure(B,S,1)[(length(H_sk)+1):A]))))
      }
      
      basic_H = function(PI,H){
        
        PI = PI-H
        return(PI)
        
      } #in cases where there is no skew hunting is applied evenly across age classes
      
      even_spread = function(reduction,neg_v,pos_v){
        
        while(length(neg_v)>0){
          
          deficit = c()
          
          for(i in 1:length(neg_v)){
            deficit[i] = reduction[neg_v[i]]
          }
          
          deficit = sum(deficit)
          
          for(i in 1:length(neg_v)){
            
            reduction[neg_v[i]] = 0
            
          }
          
          reduction_L = sum(reduction)
          
          for(i in 1:length(pos_v)){
            
            reduction[pos_v[i]] = reduction[pos_v[i]] + deficit*(reduction[pos_v[i]]/reduction_L) 
            
            neg_v = which(reduction<0)
            pos_v = which(reduction>0)
            
          }
          
        }
        
        return(reduction)
        
      } #when uneven hunting leads to depletion of an age class, deficit will be shared out based on proportion of the population 
      
      if(sum(H_sk) == 0){ 
        
        PI = basic_H(PI,H)
        
        return(PI) #with no hunting skew, basic hunting is applied across classes
        
      }else{
        
        reduction = PI-H_sk*H
        
        neg_v = which(reduction<0)
        pos_v = which(reduction>0)
        
        PI = even_spread(reduction,neg_v,pos_v)
        
        return(PI) #in cases where hunting is applied as a vector, when an age class is depleted, the quota is met with individuals from other classes
        
      }
      
    }
  }
  
  apply_E = function(PI,H,H_sk){
    
    if(length(H_sk)<A){
      H_sk = c(H_sk,(1-sum(H_sk))*(structure(B,S,1)[(length(H_sk)+1):A]/sum((structure(B,S,1)[(length(H_sk)+1):A]))))
    }
    
    basic_H = function(PI,H){
      
      PI = PI-PI*H
      return(PI)
      
    } #in cases where there is no skew entabglment is applied evenly across age classes
    
    even_spread = function(reduction,neg_v,pos_v){
      
      while(length(neg_v)>0){
        
        deficit = c()
        
        for(i in 1:length(neg_v)){
          deficit[i] = reduction[neg_v[i]]
        }
        
        deficit = sum(deficit)
        
        for(i in 1:length(neg_v)){
          
          reduction[neg_v[i]] = 0
          
        }
        
        reduction_L = sum(reduction)
        
        for(i in 1:length(pos_v)){
          
          reduction[pos_v[i]] = reduction[pos_v[i]] + deficit*(reduction[pos_v[i]]/reduction_L) 
          
          neg_v = which(reduction<0)
          pos_v = which(reduction>0)
          
        }
        
      }
      
      return(reduction)
      
    } #when uneven entanglment leads to depletion of an age class, deficit will be shared out based on proportion of the population 
    
    if(sum(H_sk) == 0){ ###########HERE#################
      
      PI = basic_H(PI,H)
      
      return(PI) #with no entanglment skew, basic entanglment is applied across classes
      
    }else{
      
      reduction = PI-H_sk*H*sum(PI)
      
      neg_v = which(reduction<0)
      pos_v = which(reduction>0)
      
      PI = even_spread(reduction,neg_v,pos_v)
      
      return(PI) #in cases where entanglment is applied as a vector, when an age class is depleted, the quota is met with individuals from other classes
      
    }
    
  }
  
  ###hunting and entanglement function end###
  
  ###stochastic###
  
  stocst = function(R,L){
    stoc = (1 - (rbeta(1,5,5)*2-1)*R)*L
    return(stoc)    
  } #random variation applied to L
  
  ###stochastic###
  
  ###first year start###

  TP = sum(P)
  L = const_leslie(B,S)
  ev = eigen(L)
  ev1 = as.numeric(ev$value[1]) #dominant eigan value (lambda), also 'long term population growth'
  
  Kef = Keffect(K,ev1,TP)
  LK = L*Kef #apply effect of carrying capacity to Leslie matrix
  LK = stocst(R,LK)
  PI = LK%*%P	 #population at t = 1 
  
  PH = apply_H(PI,H,H_sk)
  
  PE = apply_E(PI,E,E_sk)
  
  PI = PI - ((PI-PH) + (PI-PE))  #effects of hunting and entanglment are calculated for PI, no order
  
  P_out[,2] = PI
  
  ###first year end###
  
  if(t==1){
    
    if(stru == TRUE){  
      
      return(P_out) 
      
    }else{
      
      yr_sum = c()
      
      for(i in 1:ncol(P_out)){
        
        N = sum(P_out[,i])
        yr_sum[i] = N
        
      }
      
      return(yr_sum)
      
    }
    
  }else{			
    
    for(i in 2:t){
      
      TP = sum(PI)
      L = const_leslie(B,S)
      ev = eigen(L)
      ev1 = as.numeric(ev$value[1]) #dominant eigan value (lambda), also 'long term population growth'
      
      Kef = Keffect(K,ev1,TP)
      LK = L*Kef #apply effect of carrying capacity to Leslie matrix
      Kef = Keffect(K,ev1,TP)
      LK = L*Kef #apply effect of carrying capacity to Leslie matrix
      LK = stocst(R,LK)
      
      PI = LK%*%PI	 #population at t = 1 
      
      PH = apply_H(PI,H,H_sk)
      
      PE = apply_H(PI,E,E_sk)
      
      PI = PI - ((PI-PH) + (PI-PE))  #effects of hunting and entanglment are calculated for PI, no order to them
      
      P_out[,(i+1)] = PI 
      
    }
    
  }
  
  if(stru == TRUE){
    
    return(P_out) #to get all years plus age structure
    
  }else {
    
    yr_sum = c()
    
    for(i in 1:ncol(P_out)){
      
      N = sum(P_out[,i])
      yr_sum[i] = N
      
    }
    
    return(yr_sum)
    
  }
  
} #Population model, random variation dependent on stocasticity term R only

PopMod_gyby = function(t, A, K_G, K_B, K_Yr_P, P, B, S_G, S_B, Yr_P, R, H, H_sk, proportion, E, E_sk, stru){
  
  ###housekeeping and troubleshooting begin###
  
  null_args = list(H_sk,E_sk)
  null_args_names = c("H_sk","E_sk")
  for(i in 1:length(null_args)){
    if(is.null(null_args[[i]])){
      assign(paste0(null_args_names[i]), 0)
    }
  }
  
  if(length(P)!=A || (length(S_G))!=A || (length(S_B))!=A || length(B)!=A){
    stop('Lengths of P, S, & B must = A')
  }
  
  ###housekeeping and troubleshooting end###
  
  if(t==0){		
    
    if(stru == TRUE){
      
      return(P)
      
    }else{
      
      return(sum(P))
      
    }
    
  } 
  
  ###function for Leslie matrix assembly begin###
  
  const_leslie = function(B,S){
    
    B = B*S/2
    
    L = matrix(B,ncol = A) 
    
    for(i in 1:(A-1)){
      x = numeric(A)
      x[i] = S[i]
      L = rbind(L, x)
    }	
    
    return(L)
    
  }
  
  ###function for Leslie matrix assembly end###
  
  P_out = matrix(0, nrow = length(P),ncol = t+1)
  P_out[,1] = P
  
  ###carrying capacity begin### 
  
  Keffect = function(K,ev1,TP){ 
    
    if(is.null(K)){
      return(1)
    }else{
      return(((K+(ev1-1)*TP)/K)^-1)
    }  
  } #calculate the effect of carrying capactity at t based on population size at t-1, currently for best L1 matrix dominent eigen value
  
  ###carrying capacity end###
  
  ###hunting and entanglement function start###
  
  if(proportion == TRUE){
    apply_H = function(PI,H,H_sk,S){
      
      if(length(H_sk)<A){
        H_sk = c(H_sk,(1-sum(H_sk))*(structure(B,S,1)[(length(H_sk)+1):A]/sum((structure(B,S,1)[(length(H_sk)+1):A]))))
      }
      
      basic_H = function(PI,H){
        
        PI = PI-PI*H
        return(PI)
        
      } #in cases where there is no skew hunting is applied evenly across age classes
      
      even_spread = function(reduction,neg_v,pos_v){
        
        while(length(neg_v)>0){
          
          deficit = c()
          
          for(i in 1:length(neg_v)){
            deficit[i] = reduction[neg_v[i]]
          }
          
          deficit = sum(deficit)
          
          for(i in 1:length(neg_v)){
            
            reduction[neg_v[i]] = 0
            
          }
          
          reduction_L = sum(reduction)
          
          for(i in 1:length(pos_v)){
            
            reduction[pos_v[i]] = reduction[pos_v[i]] + deficit*(reduction[pos_v[i]]/reduction_L) 
            
            neg_v = which(reduction<0)
            pos_v = which(reduction>0)
            
          }
          
        }
        
        return(reduction)
        
      } #when uneven hunting leads to depletion of an age class, deficit will be shared out based on proportion of the population 
      
      if(sum(H_sk) == 0){ 
        
        PI = basic_H(PI,H)
        
        return(PI) #with no hunting skew, basic hunting is applied across classes
        
      }else{
        
        reduction = PI-H_sk*H*sum(PI)
        
        neg_v = which(reduction<0)
        pos_v = which(reduction>0)
        
        PI = even_spread(reduction,neg_v,pos_v)
        
        return(PI) #in cases where hunting is applied as a vector, when an age class is depleted, the quota is met with individuals from other classes
        
      }
      
    }
  }else if(proportion == FALSE){
    apply_H = function(PI,H,H_sk,S){
      
      if(length(H_sk)<A){
        H_sk = c(H_sk,(1-sum(H_sk))*(structure(B,S,1)[(length(H_sk)+1):A]/sum((structure(B,S,1)[(length(H_sk)+1):A]))))
      }
      
      basic_H = function(PI,H){
        
        PI = PI-H
        return(PI)
        
      } #in cases where there is no skew hunting is applied evenly across age classes
      
      even_spread = function(reduction,neg_v,pos_v){
        
        while(length(neg_v)>0){
          
          deficit = c()
          
          for(i in 1:length(neg_v)){
            deficit[i] = reduction[neg_v[i]]
          }
          
          deficit = sum(deficit)
          
          for(i in 1:length(neg_v)){
            
            reduction[neg_v[i]] = 0
            
          }
          
          reduction_L = sum(reduction)
          
          for(i in 1:length(pos_v)){
            
            reduction[pos_v[i]] = reduction[pos_v[i]] + deficit*(reduction[pos_v[i]]/reduction_L) 
            
            neg_v = which(reduction<0)
            pos_v = which(reduction>0)
            
          }
          
        }
        
        return(reduction)
        
      } #when uneven hunting leads to depletion of an age class, deficit will be shared out based on proportion of the population 
      
      if(sum(H_sk) == 0){ ###########HERE#################
        
        PI = basic_H(PI,H)
        
        return(PI) #with no hunting skew, basic hunting is applied across classes
        
      }else{
        
        reduction = PI-H_sk*H
        
        neg_v = which(reduction<0)
        pos_v = which(reduction>0)
        
        PI = even_spread(reduction,neg_v,pos_v)
        
        return(PI) #in cases where hunting is applied as a vector, when an age class is depleted, the quota is met with individuals from other classes
        
      }
      
    }
  }
  
  apply_E = function(PI,E,E_sk,S){
    
    if(length(E_sk)<A){
      E_sk = c(E_sk,(1-sum(E_sk))*(structure(B,S,1)[(length(E_sk)+1):A]/sum((structure(B,S,1)[(length(E_sk)+1):A]))))
    }
    
    basic_H = function(PI,E){
      
      PI = PI-PI*E
      return(PI)
      
    } #in cases where there is no skew entanglment is applied evenly across age classes
    
    even_spread = function(reduction,neg_v,pos_v){
      
      while(length(neg_v)>0){
        
        deficit = c()
        
        for(i in 1:length(neg_v)){
          deficit[i] = reduction[neg_v[i]]
        }
        
        deficit = sum(deficit)
        
        for(i in 1:length(neg_v)){
          
          reduction[neg_v[i]] = 0
          
        }
        
        reduction_L = sum(reduction)
        
        for(i in 1:length(pos_v)){
          
          reduction[pos_v[i]] = reduction[pos_v[i]] + deficit*(reduction[pos_v[i]]/reduction_L) 
          
          neg_v = which(reduction<0)
          pos_v = which(reduction>0)
          
        }
        
      }
      
      return(reduction)
      
    } #when uneven entanglment leads to depletion of an age class, deficit will be shared out based on proportion of the population 
    
    if(sum(E_sk) == 0){ 
      
      PI = basic_H(PI,E)
      
      return(PI) #with no entanglment skew, basic entanglment is applied across classes
      
    }else{
      
      reduction = PI-E_sk*E*sum(PI)
      
      neg_v = which(reduction<0)
      pos_v = which(reduction>0)
      
      PI = even_spread(reduction,neg_v,pos_v)
      
      return(PI) #in cases where entanglment is applied as a vector, when an age class is depleted, the quota is met with individuals from other classes
      
    }
    
  }
  
  ###hunting and entanglement function end###
  
  ###good year bad year selection function begin###
  
  gyby = function(S_G,S_B,Yr_P){
    cho = runif(1)
    if(cho > Yr_P){
      return(S_G)
    }else{
      return(S_B)
    }
  } 
  
  ###good year bad year selection function end###
  
  stocst = function(R,L){
    stoc = (1 - (rbeta(1,5,5)*2-1)*R)*L
    return(stoc)    
  } #random variation applied to L
  
  ###first year start###
  
  S_yr = gyby(S_G,S_B,Yr_P) #gyby survuval
  K_yr = gyby(K_G,K_B,K_Yr_P) #gyby carrying capacity
  TP = sum(P)
  L = const_leslie(B,S_yr)
  ev = eigen(L)
  ev1 = as.numeric(ev$value[1]) #dominant eigan value (lambda), also 'long term population growth'
  
  Kef = Keffect(K_yr,ev1,TP)
  LK = L*Kef #apply effect of carrying capacity to Leslie matrix
  LK = stocst(R,LK)
  PI = LK%*%P	 #population at t = 1 
  
  PH = apply_H(PI,H,H_sk,S_yr)
  
  PE = apply_E(PI,E,E_sk,S_yr)
  
  PI = PI - ((PI-PH) + (PI-PE))  #effects of hunting and entanglment are calculated for PI, no order to them
  
  P_out[,2] = PI
  
  ###first year end###
  
  if(t==1){
    
    if(stru == TRUE){  
      
      return(P_out) 
      
    }else{
      
      yr_sum = c()
      
      for(i in 1:ncol(P_out)){
        
        N = sum(P_out[,i])
        yr_sum[i] = N
        
      }
      
      return(yr_sum)
      
    }
    
  }else{			
    
    for(i in 2:t){
      
      S_yr = gyby(S_G,S_B,Yr_P)
      K_yr = gyby(K_G,K_B,K_Yr_P)
      
      TP = sum(PI)
      L = const_leslie(B,S_yr)
      ev = eigen(L)
      ev1 = as.numeric(ev$value[1]) #dominant eigan value (lambda), also 'long term population growth'
      
      Kef = Keffect(K_yr,ev1,TP)
      LK = L*Kef #apply effect of carrying capacity to Leslie matrix
      LK = stocst(R,LK)
      PI = LK%*%PI	 #population at t = 1 
      
      PH = apply_H(PI,H,H_sk,S_yr)
      
      PE = apply_E(PI,E,E_sk,S_yr)
      
      PI = PI - ((PI-PH) + (PI-PE))  #effects of hunting and entanglment are calculated for PI, no order to them
      
      P_out[,(i+1)] = PI 
      
    }
    
  }
  
  if(stru == TRUE){
    
    return(P_out) #to get all years plus age structure
    
  }else {
    
    yr_sum = c()
    
    for(i in 1:ncol(P_out)){
      
      N = sum(P_out[,i])
      yr_sum[i] = N
      
    }
    
    return(yr_sum)
    
  }
  
} #Population model, stocastic good year bad year dynamics
