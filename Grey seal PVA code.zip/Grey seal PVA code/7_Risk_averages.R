#Daire Carroll University of Gothenburg 2022
#Grey seal PVA script 6, estimating risks and averages for given scenarios (outcomes of 6_Scenarios.R)

rm(list=ls())
graphics.off() 

setwd("C:/Users/daire/Desktop/Projects/Grey seal PVA/HG_PVA_Code_New_Ratios")
source("1_Ordered_Scripts.R", echo = TRUE)

gt1 = generationtime(F1,S_1_Hunt)[1]
gt2 = generationtime(F2,S_2_Hunt)[1]

setwd("C:/Users/daire/Desktop/Projects/Grey seal PVA/HG_PVA_Code/Data")
my.data = read.csv("Areial_Counts.csv", sep = ",", header = TRUE, fileEncoding = 'UTF-8-BOM')
my.data2 = my.data[1:12,]
attach(my.data2)

setwd("C:/Users/daire/Desktop")

histfun = function(S,K,P0,F){
  hist_pop = matrix(nrow = length(Estimate), ncol = rep)
  for(i in 1:rep){
    
    hist_pop[,i] = PopMod(t = (length(Estimate) - 1), 
                                     A = A, 
                                     K = K, 
                                     P = structure(F,S,P0), 
                                     B = F, 
                                     S = S, 
                                     R = R, 
                                     H = 0, 
                                     H_sk = H_sk,
                                     proportion = TRUE, 
                                     E = 0, 
                                     E_sk = E_sk, 
                                     stru = FALSE)
    
  } 
  return(hist_pop)
} #simulate hitorical popualiton growth

CI = function(P,rep){
  m = rowSums(P)/rep
  i96 = 1.96*( sqrt(rowSums((P-m)^2)/rep) )
  return(i96)
}

rep = 100 #1000
subs = histfun(S1,K1,(P2009_1),F1)
hist_K1_av = c(rep(NA,9), rowSums(subs)/ncol(subs), rep(NA, (t+1)))
hist_K1_ci = c(rep(NA,9), CI(subs,rep), rep(NA, (t+1)))

subs = histfun(S2,K2,(P2009_2),F2)
hist_K2_av = c(rep(NA,9), rowSums(subs)/ncol(subs), rep(NA, (t+1)))
hist_K2_ci = c(rep(NA,9), CI(subs,rep), rep(NA, (t+1)))

hists = data.frame(cbind(hist_K1_av,hist_K1_ci,hist_K2_av,hist_K2_ci))

detach(my.data2)
attach(my.data)
  
#####################################################

E_Range = c(0) 
H_sk_range = c(1:2) 
K_range = c(K1,K2)
gt_range = c(gt1,gt2)
ice = c(1,2)

thresh_crit = (K1*0.3)
thresh_prec = (K1*0.7)

rsks_avs = function(dat,H_Range,gyby){
  
  store = data.frame(c(rev(Estimate)*0.59,rep(NA,t+1)),  c(rev(Year),c(2021:(2021+t))))
  names = c("Data","Year")
  sens = c()
  parms_store = c()
  
  q_prob_crit = c()#probability of being less than critical reference level at any point
  q_prob_prec = c()#probability of being less than precautionary reference level at any point
  iucn_10 = c() #90% decline in 3 generations
  iucn_70 = c() #70% decline in 3 generations
  iucn_50 = c() #50% decline in 3 generations
  
  if(gyby == TRUE){
    fer = c(0,0.33519)
    K_range = c(K1,K2)
    for(i in c(1:length(H_Range))){
      H = H_Range[i]
      for(j in c(1:length(fer))){
        fer_r = fer[j]
        for(k in c(1:length(H_sk_range))){
          H_skew = H_sk_range[k]
          for(l in c(1:length(K_range))){
            K = K_range[l]
            for(m in c(1:length(ice))){
              
              ic = ice[m]
              
              gt = gt_range[l]
              
              subs = dat[,which(dat[1,] == H & dat[2,] == fer_r & dat[3,] == H_skew & dat[4,] == ic & dat[5,] == K)]
              
              rep = ncol(subs)
              
              parms = c(H,fer_r,H_skew,ic,K)
              
              parms_store = rbind(parms_store,parms)
              
              av = rowSums(subs)/ncol(subs)
              
              er = CI(subs,ncol(subs)) 
              
              store = cbind(store, c(rep(NA,length(Year)),av[6:length(av)]), c(rep(NA,length(Year)), er[6:length(av)]))
              
              names = c(names, paste0("H",H,"fer_r",fer_r,"H_sk",H_skew,"Ice",ic,"K",K,"av",sep = "") , paste0("H",H,"fer_r",fer_r,"H_sk",H_skew,"Ice",ic,"K",K,"CI",sep = ""))
              
              names(store) = names
              
              sens = c(sens, paste0("H",H,"fer_r",fer_r,"H_sk",H_skew,"Ice",ic,"K",K,sep = ""))
              
              message(paste0("H",H,"fer_r",fer_r,"H_sk",H_skew,"Ice",ic,"K",K,sep = ""))
              
              q_crit = 0
              q_prec = 0
              iu_10 = 0
              iu_70 = 0
              iu_50 = 0
              
              for(m in c(1:ncol(subs))){
                
                cur = subs[,m][5:nrow(subs)]
                
                if(cur[length(na.omit(cur))] < thresh_crit){
                  r = 1
                }else{
                  r = 0
                }
                q_crit = q_crit + r ### 
                
                if(cur[length(na.omit(cur))] < thresh_prec){
                  r = 1
                }else{
                  r = 0
                }
                q_prec = q_prec + r
                
                if(min(na.omit(cur[1:(3*round(as.numeric(gt)))])) < P01*0.9){
                  r = 1
                }else{
                  r = 0
                }
                iu_10 = iu_10 + r
                
                if(min(na.omit(cur[1:(3*round(as.numeric(gt)))])) < P01*0.3){
                  r = 1
                }else{
                  r = 0
                }
                
                iu_70 = iu_70 + r
                
                if(min(na.omit(cur[1:(3*round(as.numeric(gt)))])) < P01*0.5){
                  r = 1
                }else{
                  r = 0
                }
                
                iu_50 = iu_50 + r
                
              }
              
              iu_10 = iu_10/rep
              iu_70 = iu_70/rep
              iu_50 = iu_50/rep
              q_crit = q_crit/rep 
              q_prec = q_prec/rep
              
              q_prob_crit = c(q_prob_crit,q_crit)
              q_prob_prec = c(q_prob_prec,q_prec)
              iucn_10 = c(iucn_10,iu_10) 
              iucn_70 = c(iucn_70,iu_70) 
              iucn_50 = c(iucn_50,iu_50) 
              
            }
          }
        }
      }
    } 
    store = cbind(store,hists)
    risks = data.frame(sens, q_prob_crit, q_prob_prec, iucn_10,iucn_70,iucn_50)
    risks = cbind(parms_store,risks)
    names(risks) = c("H","E","Skew","Ice","K","Scenario","crit_prob","prec_prob","iucn_10","iucn_70","iucn_50")
    
    newList = list("Risks" = risks, "Averages" = store)
    return(newList)
    
  }else if(gyby == FALSE){
    
    K_range = c(K1,K2)
    
    for(i in c(1:length(H_Range))){
      H = H_Range[i]
      for(j in c(1:length(E_Range))){
        E = E_Range[j]
        for(k in c(1:length(H_sk_range))){
          H_skew = H_sk_range[k]
          for(l in c(1:length(K_range))){
            fer = rbind(c(0,0.335), c(0,(0.333)))
            K = K_range[l]
            fer = fer[l,]
            for(m in c(1:length(fer))){
              
              f = fer[m]
              
              gt = gt_range[l]
              
              subs = dat[,which(dat[1,] == H & dat[2,] == E & dat[3,] == H_skew & dat[4,] == K & dat[5,] == f)]
              
              rep = ncol(subs)
              
              parms = c(H,E,H_skew,K,f)
              
              parms_store = rbind(parms_store,parms)
              
              av = rowSums(subs)/ncol(subs)
              
              er = CI(subs,ncol(subs))
              
              store = cbind(store, c(rep(NA,length(Year)),av[6:length(av)]), c(rep(NA,length(Year)), er[6:length(av)]))
              
              names = c(names, paste0("H",H,"E",E,"H_sk",H_skew,"K",K,"fer",f,"av",sep = "") , paste0("H",H,"E",E,"H_sk",H_skew,"K",K,"fer",f,"CI",sep = ""))
              
              names(store) = names
              
              sens = c(sens, paste0("H",H,"E",E,"H_sk",H_skew,"K",K,"fer",f,sep = ""))
              
              message(paste0("H",H,"E",E,"H_sk",H_skew,"K",K,"fer",f,sep = ""))
              
              q_crit = 0
              q_prec = 0
              iu_10 = 0
              iu_70 = 0
              iu_50 = 0
              
              for(n in c(1:ncol(subs))){
                
                cur = subs[,n][7:nrow(subs)]
                
                if(cur[length(na.omit(cur))] < thresh_crit){
                  r = 1
                }else{
                  r = 0
                }
                q_crit = q_crit + r ### 
                
                if(cur[length(na.omit(cur))] < thresh_prec){
                  r = 1
                }else{
                  r = 0
                }
                q_prec = q_prec + r
                
                if(min(na.omit(cur[1:(3*round(as.numeric(gt)))])) < P01*0.9){
                  r = 1
                }else{
                  r = 0
                }
                iu_10 = iu_10 + r
                
                if(min(na.omit(cur[1:(3*round(as.numeric(gt)))])) < P01*0.3){
                  r = 1
                }else{
                  r = 0
                }
                
                iu_70 = iu_70 + r
                
                if(min(na.omit(cur[1:(3*round(as.numeric(gt)))])) < P01*0.5){
                  r = 1
                }else{
                  r = 0
                }
                
                iu_50 = iu_50 + r
                
              }
              
              iu_10 = iu_10/rep
              iu_70 = iu_70/rep
              iu_50 = iu_50/rep
              q_crit = q_crit/rep 
              q_prec = q_prec/rep
              
              q_prob_crit = c(q_prob_crit,q_crit)
              q_prob_prec = c(q_prob_prec,q_prec)
              iucn_10 = c(iucn_10,iu_10) 
              iucn_70 = c(iucn_70,iu_70) 
              iucn_50 = c(iucn_50,iu_50) 
              
            }
          }
        }
      }
    } 
    
    store = cbind(store,hists)
    risks = data.frame(sens, q_prob_crit, q_prob_prec, iucn_10,iucn_70,iucn_50)
    risks = cbind(parms_store,risks)
    names(risks) = c("H","E","Skew","K","Fer","Scenario","crit_prob","prec_prob","iucn_10","iucn_70","iucn_50")
    
    newList = list("Risks" = risks, "Averages" = store)
    return(newList)
    
  }  
  
}  #estimate risks and averages for given data set of simulations (dat), under conditions of number of variable parameters (no_parms), hunting range (H_Range_P, H_Range_Q), if the simulation contains good year bad year dynamics (GYBY = TRUE/FALSE) 

setwd("C:/Users/daire/Desktop/")
dat = read.csv("GYBY_Q_R.csv", sep = ",", header = TRUE, fileEncoding = 'UTF-8-BOM')
H_Range_Q = c(0,400,800,1200,1600,2000,2400,2800,3200,3600,4000) #seals hunted, quota
H_Range_Q = H_Range_Q*0.43 #Hunt_Ratio #0.5   females hunted, quota
GYBY_Q_str = rsks_avs(dat,H_Range_Q,TRUE)
setwd("C:/Users/daire/Desktop/New_Ratios_Oct_PVA/")
write.csv(GYBY_Q_str$Risks, "GYBY_Risks_0.43.csv")
write.csv(GYBY_Q_str$Averages, "GYBY_Avs_0.43.csv")

setwd("C:/Users/daire/Desktop/")
dat = read.csv("GYBY_Q_R_0.5_ratio.csv", sep = ",", header = TRUE, fileEncoding = 'UTF-8-BOM')
H_Range_Q = c(0,400,800,1200,1600,2000,2400,2800,3200,3600,4000) #seals hunted, quota
H_Range_Q = H_Range_Q*0.5 #Hunt_Ratio #0.5   females hunted, quota
GYBY_Q_str = rsks_avs(dat,H_Range_Q,TRUE)
setwd("C:/Users/daire/Desktop/")
write.csv(GYBY_Q_str$Risks, "GYBY_Risks_R_0.5.csv")
write.csv(GYBY_Q_str$Averages, "GYBY_Avs_R_0.5.csv")

setwd("C:/Users/daire/Desktop/")
dat = read.csv("Multistress_Q.csv", sep = ",", header = TRUE, fileEncoding = 'UTF-8-BOM')
dat[5,which(dat[5,] == 0.333333333333333)] = 0.333
dat[5,which(dat[5,] == 0.33519 )] = 0.335
H_Range_Q = c(0,400,800,1200,1600,2000,2400,2800,3200,3600,4000) #seals hunted, quota
H_Range_Q = H_Range_Q*0.43 #Hunt_Ratio #0.5   females hunted, quota
Fer_Q = rsks_avs(dat,H_Range_Q,FALSE)
setwd("C:/Users/daire/Desktop/")
write.csv(Fer_Q$Risks, "Multistress_Risks_0.43.csv")
write.csv(Fer_Q$Averages, "Multistress_Avs_0.43.csv")

setwd("C:/Users/daire/Desktop/")
dat = read.csv("Multistress_Q_0.5.csv", sep = ",", header = TRUE, fileEncoding = 'UTF-8-BOM')
dat[5,which(dat[5,] == 0.333333333333333)] = 0.333
dat[5,which(dat[5,] == 0.33519 )] = 0.335
H_Range_Q = c(0,400,800,1200,1600,2000,2400,2800,3200,3600,4000) #seals hunted, quota
H_Range_Q = H_Range_Q*0.5 #Hunt_Ratio #0.5   females hunted, quota
Fer_Q = rsks_avs(dat,H_Range_Q,FALSE)
setwd("C:/Users/daire/Desktop/")
write.csv(Fer_Q$Risks, "Multistress_Risks_0.5.csv")
write.csv(Fer_Q$Averages, "Multistress_Avs_0.5.csv")

#####################################################
